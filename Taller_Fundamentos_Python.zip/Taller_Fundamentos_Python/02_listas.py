# TEMA 2: LISTAS

# EJERCICIO 1: Crear una lista con cinco ciudades
print("EJERCICIO 1")
ciudades = ["Bogotá", "Medellín", "Cali", "Cartagena", "Barranquilla"]
print("Primera ciudad:", ciudades[0])
print("Última ciudad:", ciudades[-1])

# EJERCICIO 2: Agregar dos ciudades y eliminar una
print("\nEJERCICIO 2")
ciudades.append("Bucaramanga")
ciudades.append("Pereira")
ciudades.remove("Cali")
print("Lista final:", ciudades)

# EJERCICIO 3: Ordenar seis números de mayor a menor
print("\nEJERCICIO 3")
numeros = [15, 8, 30, 4, 22, 10]
numeros.sort(reverse=True)
print("Números ordenados:", numeros)

# EJERCICIO 4: Suma, mayor y menor
print("\nEJERCICIO 4")
valores = [10, 20, 5, 40, 15]
print("Suma:", sum(valores))
print("Mayor:", max(valores))
print("Menor:", min(valores))
