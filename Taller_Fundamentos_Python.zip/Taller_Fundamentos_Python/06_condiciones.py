# TEMA 6: CONDICIONES

# EJERCICIO 1: Indicar si un número es positivo, negativo o cero
print("EJERCICIO 1")
numero = float(input("Ingresa un número: "))
if numero > 0:
    print("El número es positivo")
elif numero < 0:
    print("El número es negativo")
else:
    print("El número es cero")

# EJERCICIO 2: Verificar si un año es bisiesto
print("\nEJERCICIO 2")
anio = int(input("Ingresa un año: "))
if (anio % 4 == 0 and anio % 100 != 0) or anio % 400 == 0:
    print("Es un año bisiesto")
else:
    print("No es un año bisiesto")

# EJERCICIO 3: Saludo según la hora
print("\nEJERCICIO 3")
hora = int(input("Ingresa la hora (0 a 23): "))
if 0 <= hora <= 11:
    print("Buenos días")
elif 12 <= hora <= 17:
    print("Buenas tardes")
elif 18 <= hora <= 23:
    print("Buenas noches")
else:
    print("Hora no válida")

# EJERCICIO 4: Promedio de tres notas y aprobación
print("\nEJERCICIO 4")
nota1 = float(input("Primera nota: "))
nota2 = float(input("Segunda nota: "))
nota3 = float(input("Tercera nota: "))
promedio = (nota1 + nota2 + nota3) / 3
print("Promedio:", round(promedio, 2))
if promedio >= 3.0:
    print("Aprueba")
else:
    print("No aprueba")
