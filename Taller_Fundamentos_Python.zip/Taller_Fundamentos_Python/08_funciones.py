# TEMA 8: FUNCIONES

# EJERCICIO 1: Función que indica si un número es par
print("EJERCICIO 1")
def es_par(n):
    return n % 2 == 0

print(es_par(8))
print(es_par(7))

# EJERCICIO 2: Área de un círculo
print("\nEJERCICIO 2")
def area_circulo(radio):
    return 3.1416 * radio ** 2

print("Área del círculo:", area_circulo(5))

# EJERCICIO 3: Devolver el mayor de una lista sin usar max()
print("\nEJERCICIO 3")
def numero_mayor(lista):
    mayor = lista[0]
    for numero in lista:
        if numero > mayor:
            mayor = numero
    return mayor

print("Número mayor:", numero_mayor([4, 12, 7, 25, 9]))

# EJERCICIO 4: Factorial usando un ciclo
print("\nEJERCICIO 4")
def factorial(n):
    resultado = 1
    for numero in range(1, n + 1):
        resultado *= numero
    return resultado

print("Factorial de 5:", factorial(5))
