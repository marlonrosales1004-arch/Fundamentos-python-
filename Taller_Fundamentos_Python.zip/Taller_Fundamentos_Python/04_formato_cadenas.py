# TEMA 4: FORMATO DE CADENAS

# EJERCICIO 1: Presentación usando f-strings
print("EJERCICIO 1")
nombre = "Daniela"
edad = 18
ciudad = "Bogotá"
print(f"Me llamo {nombre}, tengo {edad} años y vivo en {ciudad}.")

# EJERCICIO 2: Mostrar precio con dos decimales
print("\nEJERCICIO 2")
precio = 1999.5
print(f"Precio: {precio:.2f}")

# EJERCICIO 3: Tabla del 7 usando format()
print("\nEJERCICIO 3")
for numero in range(1, 4):
    print("7 x {} = {}".format(numero, 7 * numero))

# EJERCICIO 4: Entero con ceros a la izquierda
print("\nEJERCICIO 4")
n = 7
print("Código: {:03d}".format(n))
