# TEMA 7: CICLOS

# EJERCICIO 1: Imprimir números pares del 1 al 50
print("EJERCICIO 1")
for numero in range(2, 51, 2):
    print(numero)

# EJERCICIO 2: Sumar números del 1 al 100
print("\nEJERCICIO 2")
suma = 0
for numero in range(1, 101):
    suma += numero
print("La suma del 1 al 100 es:", suma)

# EJERCICIO 3: Tabla de multiplicar de un número ingresado
print("\nEJERCICIO 3")
numero = int(input("Ingresa un número para ver su tabla: "))
for i in range(1, 11):
    print(f"{numero} x {i} = {numero * i}")

# EJERCICIO 4: Pedir clave hasta que sea correcta
print("\nEJERCICIO 4")
clave_correcta = "python123"
clave = input("Ingresa la clave: ")
while clave != clave_correcta:
    print("Clave incorrecta. Intenta nuevamente.")
    clave = input("Ingresa la clave: ")
print("¡Acceso permitido!")
