# TEMA 12: ENTRADA Y SALIDA

# EJERCICIO 1: Pedir dos números y mostrar operaciones
print("EJERCICIO 1")
numero1 = float(input("Ingresa el primer número: "))
numero2 = float(input("Ingresa el segundo número: "))
print("Suma:", numero1 + numero2)
print("Resta:", numero1 - numero2)
print("Multiplicación:", numero1 * numero2)
if numero2 != 0:
    print("División:", numero1 / numero2)
else:
    print("No se puede dividir entre cero")

# EJERCICIO 2: Guardar nombre y ficha en registro.txt
print("\nEJERCICIO 2")
nombre = input("Ingresa el nombre del aprendiz: ")
ficha = input("Ingresa la ficha del aprendiz: ")
with open("registro.txt", "w", encoding="utf-8") as archivo:
    archivo.write("Nombre: " + nombre + "\n")
    archivo.write("Ficha: " + ficha + "\n")
print("Datos guardados en registro.txt")

# EJERCICIO 3: Leer registro.txt línea por línea
print("\nEJERCICIO 3")
with open("registro.txt", "r", encoding="utf-8") as archivo:
    for linea in archivo:
        print(linea.strip())

# EJERCICIO 4: Calcular promedio de tres notas y guardarlo
print("\nEJERCICIO 4")
nota1 = float(input("Ingresa la primera nota: "))
nota2 = float(input("Ingresa la segunda nota: "))
nota3 = float(input("Ingresa la tercera nota: "))
promedio = (nota1 + nota2 + nota3) / 3

if promedio >= 3.0:
    mensaje = "Aprobó"
else:
    mensaje = "No aprobó"

with open("resultado_notas.txt", "w", encoding="utf-8") as archivo:
    archivo.write(f"Promedio: {promedio:.2f}\n")
    archivo.write(mensaje)

print("Promedio:", round(promedio, 2))
print(mensaje)
print("Resultado guardado en resultado_notas.txt")
