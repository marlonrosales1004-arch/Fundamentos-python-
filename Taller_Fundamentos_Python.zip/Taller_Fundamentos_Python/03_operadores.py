# TEMA 3: OPERADORES BÁSICOS

# EJERCICIO 1: Área y perímetro de un rectángulo
print("EJERCICIO 1")
base = 8
altura = 5
area = base * altura
perimetro = 2 * (base + altura)
print("Área:", area)
print("Perímetro:", perimetro)

# EJERCICIO 2: Verificar si un número es par
print("\nEJERCICIO 2")
numero = 14
if numero % 2 == 0:
    print(numero, "es par")
else:
    print(numero, "es impar")

# EJERCICIO 3: Convertir Celsius a Fahrenheit
print("\nEJERCICIO 3")
celsius = 100
fahrenheit = celsius * 9 / 5 + 32
print(celsius, "°C equivalen a", fahrenheit, "°F")

# EJERCICIO 4: Verificar si un número está entre 10 y 20
print("\nEJERCICIO 4")
numero = 15
print("¿Está entre 10 y 20?:", numero >= 10 and numero <= 20)
