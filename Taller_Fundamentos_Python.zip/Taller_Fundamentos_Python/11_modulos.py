# TEMA 11: MÓDULOS Y PAQUETES

# EJERCICIO 1: Área de círculo con math y round()
print("EJERCICIO 1")
import math
radio = 5
area = math.pi * radio ** 2
print("Área del círculo:", round(area, 2))

# EJERCICIO 2: Lanzar un dado cinco veces con random
print("\nEJERCICIO 2")
from random import randint
for lanzamiento in range(5):
    print("Lanzamiento", lanzamiento + 1, ":", randint(1, 6))

# EJERCICIO 3: Importar funciones desde calculadora.py
print("\nEJERCICIO 3")
from calculadora import sumar, restar
print("Suma:", sumar(10, 5))
print("Resta:", restar(10, 5))

# EJERCICIO 4: Mostrar la fecha de hoy con datetime
print("\nEJERCICIO 4")
import datetime
print("Fecha de hoy:", datetime.date.today())
