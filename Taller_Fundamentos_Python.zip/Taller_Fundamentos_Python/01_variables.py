# TEMA 1: VARIABLES Y TIPOS
# EJERCICIO 1: Crear variables e imprimirlas
nombre = "Daniela"
edad = 18
estatura = 1.60
es_aprendiz = True

print("EJERCICIO 1")
print("Nombre:", nombre)
print("Edad:", edad)
print("Estatura:", estatura)
print("Es aprendiz:", es_aprendiz)

# EJERCICIO 2: Mostrar el tipo de cada variable
print("\nEJERCICIO 2")
print("Tipo de nombre:", type(nombre))
print("Tipo de edad:", type(edad))
print("Tipo de estatura:", type(estatura))
print("Tipo de es_aprendiz:", type(es_aprendiz))

# EJERCICIO 3: Convertir texto a decimal y sumarle 1
print("\nEJERCICIO 3")
numero = float("3.75")
resultado = numero + 1
print("Resultado:", resultado)

# EJERCICIO 4: Intercambiar dos valores sin una tercera variable
print("\nEJERCICIO 4")
x = 10
y = 20
x, y = y, x
print("Valor de x:", x)
print("Valor de y:", y)
