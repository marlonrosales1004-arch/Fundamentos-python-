# TEMA 10: DICCIONARIOS

# EJERCICIO 1: Diccionario con datos de un libro
print("EJERCICIO 1")
libro = {"titulo": "Cien años de soledad", "autor": "Gabriel García Márquez", "anio": 1967}
print("Título:", libro["titulo"])
print("Autor:", libro["autor"])
print("Año:", libro["anio"])

# EJERCICIO 2: Cuatro productos y calcular el total
print("\nEJERCICIO 2")
productos = {
    "Arroz": 3000,
    "Leche": 4500,
    "Pan": 2000,
    "Huevos": 8000
}
total = sum(productos.values())
print("Productos:", productos)
print("Total:", total)

# EJERCICIO 3: Buscar palabra en diccionario español-inglés
print("\nEJERCICIO 3")
traducciones = {"casa": "house", "perro": "dog", "gato": "cat", "libro": "book"}
palabra = input("Escribe una palabra en español: ").lower()
if palabra in traducciones:
    print("Traducción:", traducciones[palabra])
else:
    print("La palabra no está en el diccionario")

# EJERCICIO 4: Contar cuántas veces aparece cada palabra
print("\nEJERCICIO 4")
frase = input("Escribe una frase corta: ").lower()
conteo = {}
for palabra in frase.split():
    conteo[palabra] = conteo.get(palabra, 0) + 1
print("Conteo de palabras:", conteo)
