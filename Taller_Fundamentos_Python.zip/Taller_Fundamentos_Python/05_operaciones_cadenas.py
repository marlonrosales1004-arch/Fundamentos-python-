# TEMA 5: OPERACIONES BÁSICAS CON CADENAS

# EJERCICIO 1: Pedir una palabra y contar sus caracteres
print("EJERCICIO 1")
palabra = input("Escribe una palabra: ")
print("Cantidad de caracteres:", len(palabra))

# EJERCICIO 2: Quitar espacios y convertir a mayúsculas
print("\nEJERCICIO 2")
frase = " hola mundo "
print(frase.strip().upper())

# EJERCICIO 3: Contar cuántas veces aparece la letra a
print("\nEJERCICIO 3")
frase = input("Escribe una frase: ")
print("La letra a aparece:", frase.lower().count("a"), "veces")

# EJERCICIO 4: Invertir una cadena y verificar palíndromo
print("\nEJERCICIO 4")
texto = input("Escribe una palabra: ")
invertido = texto[::-1]
print("Texto invertido:", invertido)
if texto.lower() == invertido.lower():
    print("Es un palíndromo")
else:
    print("No es un palíndromo")
