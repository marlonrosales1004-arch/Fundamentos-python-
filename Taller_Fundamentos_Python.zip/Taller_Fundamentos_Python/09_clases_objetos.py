# TEMA 9: CLASES Y OBJETOS

# EJERCICIO 1: Clase Aprendiz
print("EJERCICIO 1")
class Aprendiz:
    def __init__(self, nombre, ficha):
        self.nombre = nombre
        self.ficha = ficha

    def mostrar_datos(self):
        print("Nombre:", self.nombre)
        print("Ficha:", self.ficha)

aprendiz = Aprendiz("Daniela", "ADSO")
aprendiz.mostrar_datos()

# EJERCICIO 2: Clase Rectangulo
print("\nEJERCICIO 2")
class Rectangulo:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura

    def area(self):
        return self.base * self.altura

    def perimetro(self):
        return 2 * (self.base + self.altura)

rectangulo = Rectangulo(8, 5)
print("Área:", rectangulo.area())
print("Perímetro:", rectangulo.perimetro())

# EJERCICIO 3: Cuenta con método retirar sin saldo negativo
print("\nEJERCICIO 3")
class Cuenta:
    def __init__(self, saldo=0):
        self.saldo = saldo

    def depositar(self, valor):
        self.saldo += valor

    def retirar(self, valor):
        if valor <= self.saldo:
            self.saldo -= valor
            print("Retiro realizado")
        else:
            print("Saldo insuficiente")

cuenta = Cuenta(1000)
cuenta.retirar(300)
print("Saldo actual:", cuenta.saldo)
cuenta.retirar(900)

# EJERCICIO 4: Vehiculo y subclase Moto
print("\nEJERCICIO 4")
class Vehiculo:
    def describir(self):
        print("Este es un vehículo")

class Moto(Vehiculo):
    def describir(self):
        print("Esta es una moto")

vehiculo = Vehiculo()
moto = Moto()
vehiculo.describir()
moto.describir()
