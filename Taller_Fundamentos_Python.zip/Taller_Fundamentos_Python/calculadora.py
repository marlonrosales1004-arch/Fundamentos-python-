# Módulo propio para el ejercicio 3 del Tema 11

def sumar(a, b):
    return a + b

def restar(a, b):
    return a - b
